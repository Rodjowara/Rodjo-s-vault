#include <stdio.h>
#include "CButton.h"
#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "sdkconfig.h"
#include "esp_timer.h"

gpio_num_t m_pinNumber;
const char *LogName = "CButton";

CButton::CButton(int port){
    m_pinNumber = (gpio_num_t)port;
    ESP_LOGI(LogName, "Configure port[%d] to input!!!", port);
    gpio_reset_pin(m_pinNumber);
    gpio_set_direction(m_pinNumber, GPIO_MODE_INPUT);
    gpio_set_pull_mode(m_pinNumber, GPIO_PULLUP_ONLY);
}

void CButton::tick(){
    static bool lastState = 1;
    static int64_t lastDebounceTime = 0;
    static int64_t pressStartTime = 0;
    static int64_t lastReleaseTime = 0;
    static int clickCount = 0;

    const int debounceDelay = 50;
    const int doubleClickDelay = 300;
    const int longPressDelay = 1000;

    bool currentState = gpio_get_level(m_pinNumber); // 1 = released, 0 = pressed
    int64_t now = esp_timer_get_time() / 1000; // ms

    // debounce
    if (currentState != lastState) {
        lastDebounceTime = now;
    }

    if ((now - lastDebounceTime) > debounceDelay) {

        // PRITISAK
        if (currentState == 0 && lastState == 1) {
            pressStartTime = now;
        }

        // OTPUŠTANJE
        if (currentState == 1 && lastState == 0) {
            int pressDuration = now - pressStartTime;

            // LONG PRESS
            if (pressDuration >= longPressDelay) {
                if (longPress) longPress();
                clickCount = 0;
            } 
            else {
                clickCount++;
                lastReleaseTime = now;
            }
        }

        // DOUBLE / SINGLE LOGIKA
        if (clickCount > 0 && (now - lastReleaseTime) > doubleClickDelay) {
            if (clickCount == 1) {
                if (singleClick) singleClick();
            }    
            else if (clickCount >= 2) {
                if (doubleClick) doubleClick();
            }
            clickCount = 0;
        }
    }

    lastState = currentState;
}